list1=[10,20,40,60,70,80]
list2=[5,15,25,35,45,60]
list=list1+list2
for i in list:
min(list)
min(list)+1
list
