list 1=[0,1,2,10,4,1,0,56,2,0,1,3,0,56,0,4]

list1.sort(reverse=1)

Print (list1)