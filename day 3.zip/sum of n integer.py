n=int (input("enter n value"))
sum=0
for i in range(0,n)
num=int(input("enter the number"))
sum=sum+num
print(sum)